pick_a_national_GDP_4web


		
# 简介 
选取的国家名称，操练Python语言开发练习：使用flask


		
## 输入：
用户输入国家名称
## 输出：
用户得到输出结果为：该国家近年GDP
## 从输入到输出，本组作品使用了：
### 模块
* [csv](https://github.com/thephpleague/csv)
### 数据
* [country-name](https://github.com/hanteng/country-names/blob/master/data/CLDR_country_name_zh-Hans.tsv)
* [national_GDP](https://www.cia.gov/library/publications/download/index.html)
### API
* [github](https://api.github.com/)

## 作者成员：
见[_team_.tsv](_team_/_team_.tsv)


		成员列表，统计用，一人一行，输入Github 帐户名即可（此行完成後应删）
